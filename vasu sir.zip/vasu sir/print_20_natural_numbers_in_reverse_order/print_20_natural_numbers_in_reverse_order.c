//Program to print first 20 natural numbers in reverse order

#include<stdio.h>

int main()
{
	int number = 20;

	for(int i = number ; i > 0 ; i--)
	{
		printf("%d ",i);
	}

	return 0;
}
