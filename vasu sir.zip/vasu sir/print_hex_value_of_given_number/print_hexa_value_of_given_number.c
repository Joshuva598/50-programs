#include <stdio.h> 

int main() 
{ 
	int decimalNumber;
	
	printf("Enter decimal number :");
	scanf("%d",&decimalNumber);
	
	
	printf("Hexadecimal number is: %X", decimalNumber); 
	return 0; 
}

