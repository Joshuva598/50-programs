//Program to print_first_20_natural_numbers

#include<stdio.h>

int main()
{
	printf("First 20 natural numbers \n");

	for(int i = 0 ; i < 20 ; i++)
	{
		printf("%d ",i+1);
	}

	return 0;
}
